# My Budget Android APK

This is an offline Android wrapper around the My Budget web app. The app stores its data locally and runs without internet after installation.

## Build without Android Studio
1. Upload this folder to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build My Budget APK**.
4. Click **Run workflow**.
5. When the workflow finishes, open the run and download the **MyBudget-debug-apk** artifact.
6. Extract the ZIP and install `app-debug.apk` on Android.

For Play Store distribution, create a signed release build instead of using the debug APK.
